import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class MyWindow extends JFrame implements ActionListener {

    JTextArea textArea = new JTextArea(6,12);
    JTextArea sortArea = new JTextArea(6,12);
    JTextField minField = new JTextField(38);
    JTextArea textAreaForNames = new JTextArea(6,12);



    public MyWindow() throws SQLException {
        setLayout(new FlowLayout());
        add(textArea);
        add(minField);
        add(sortArea);
        add(textAreaForNames);
        StudentDAO studentDAO = new StudentDAO();
        textArea.setText(studentDAO.print()+"");
        minField.setText(studentDAO.min());
//        sortArea.setText(studentDAO.sortPrint()+"");
        sortArea.setText(studentDAO.printByNameSort()
                +"");
        //        textAreaForNames.setText(studentDAO.countTheSameName()+"");
    textAreaForNames.setText(studentDAO.mostPopularHBD());

        setName("My Window");
        setSize(500,500);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
