import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StudentDAO {

    List<Student> studentList = new ArrayList<Student>();

    public List<Student> getStudents() {
        return studentList;
    }

    public void setStudents(List<Student> students) {
        this.studentList = students;
    }

    public void fillStudent() throws SQLException {
        Statement statement = null;
        statement = ConnectionDB.getConnection().createStatement();
        ResultSet rs = statement.executeQuery("select * from student");
        while (rs.next()) {
            String name = rs.getString(1);
            String surname = rs.getString(2);
            int progress = rs.getInt(3);
            int age = rs.getInt(4);
            Student student = new Student(name, surname, progress, age);
            studentList.add(student);
        }
    }

    public String print() throws SQLException {
        fillStudent();
        String s = "";
        for (int i = 0; i < studentList.size(); i++) {
            s += studentList.get(i).toString() + "\n";
        }
        return s;
    }

    public void sort() throws SQLException {
        Student temp;
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = 0; j < studentList.size() - 1; j++) {
                if (studentList.get(j).getAge() > studentList.get(j + 1).getAge()) {
                    temp = studentList.get(j);
                    studentList.set(j, studentList.get(j + 1));
                    studentList.set(j + 1, temp);
                }
            }
        }
    }

    public String sortPrint() throws SQLException {
        String s = "";
        for (int i = 0; i < studentList.size(); i++) {
            s += studentList.get(i).toString() + "\n";
        }
        return s;
    }

    public String min() throws SQLException {
        Student min = studentList.get(0);
        String s = "";
        for (int i = 0; i < studentList.size(); i++) {
            if (studentList.get(i).getAge() < min.getAge()) {
                min = studentList.get(i);
            }
        }
        s += min.toString() + "\n";
        return s;
    }

    public void sortByName() throws SQLException {
        Student temp;
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = 0; j < studentList.size() - 1; j++) {
                if (studentList.get(j).getName().compareTo(studentList.get(j + 1).getName()) > 0) {
                    temp = studentList.get(j);
                    studentList.set(j, studentList.get(j + 1));
                    studentList.set(j + 1, temp);
                }
            }
        }
    }

    public String printByNameSort() throws SQLException {
        sortByName();
        String s = "";
        for (int i = 0; i < studentList.size(); i++) {
            s += studentList.get(i).toString() + "\n";
        }
        return s;
    }

    public int countTheSameName() throws SQLException {
        int count = 0;
        for (int i = 0; i < studentList.size(); i++) {
            for (int j = 0; j < studentList.size(); j++) {
                if (i != j && studentList.get(i).getName().equals(studentList.get(j).getName())) {
                    count++;
                }
            }
        }
        count = count / 2;
        return count;
    }
    public String mostPopularHBD() throws SQLException {

        for (int i = 0; i <studentList.size() ; i++) {

        }
    }

}