public class Student {
    private String name;
    private String surname;
    private int progress;
    private int age;

    public Student(String name, String surname, int progress, int age) {
        this.name = name;
        this.surname = surname;
        this.progress = progress;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }



    public int getProgress() {
        return progress;
    }

    public void setProgress(int progress) {
        this.progress = progress;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", progress=" + progress +
                ", age=" + age +
                '}';
    }
}
